-- require("ctrl_escape")
require("oh-my-hammerspoon")

omh_go({
    -- "apps.hammerspoon_toggle_console",
    -- "apps.hammerspoon_install_cli",
    "apps.hammerspoon_config_reload",
    -- "windows.manipulation",
    -- "windows.grid",
    "apps.launcher",

    -- "audio.headphones_watcher",
    -- "misc.clipboard",
    -- "keyboard.menubar_indicator",
    "keyboard.hyper",
    -- "apps.universal_archive",
    -- "windows.screen_rotate",
    -- "windows.tabs",
    -- "apps.evernote",
    -- "misc.url_handling",
    --      "misc.presentation",
})
