-- Toggle Hammerspoon Console
hs.hotkey.bind({"cmd", "alt", "ctrl"}, 'y', hs.toggleConsole)
