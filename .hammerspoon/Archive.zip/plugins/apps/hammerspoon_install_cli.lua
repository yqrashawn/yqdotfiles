-- Ensure the IPC command line client is available
hs.ipc.cliInstall()
